package com.ucatolica.easyevent.easyevent.entities;

public enum Erol {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN
}
