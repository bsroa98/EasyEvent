package com.ucatolica.easyevent.easyevent.repositories;

import com.ucatolica.easyevent.easyevent.entities.Proveedor;
import org.springframework.data.repository.CrudRepository;

public interface ProveedorCrudRepository extends CrudRepository<Proveedor,Integer> {


}
