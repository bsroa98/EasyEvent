package com.ucatolica.easyevent.easyevent.repositories;
import com.ucatolica.easyevent.easyevent.entities.Evento;
import org.springframework.data.repository.CrudRepository;
public interface EventoCrudRepository extends CrudRepository<Evento, Integer> {

}
