package com.ucatolica.easyevent.easyevent.services;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

class EmailServiceTest {

    @Autowired
    private EmailService emailService;
    @Test
    void sendEmail() {
    }
}