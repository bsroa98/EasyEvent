package com.ucatolica.easyevent.easyevent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyeventApplicationTests {

	@Test
	void contextLoads() {
	}

}
